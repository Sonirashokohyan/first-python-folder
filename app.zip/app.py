print("Inqualities")

if 121 > 120:
    print("121 is greater than 120")

if -10 < -2:
    print("The basis of a number with a negative sign, the smallest coefficient is the larger number")

x = 20
print("Y=20")

if not 20 > 21:
    print("false")

if 0 > -1:
    print("true")

if x > 0:
    print("this equation has two solution")

y = 0
print("x=3")